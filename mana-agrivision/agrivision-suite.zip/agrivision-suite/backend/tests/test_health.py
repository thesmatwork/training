from fastapi.testclient import TestClient
from app.main import app

def test_health_endpoint():
    response=TestClient(app).get("/health")
    assert response.status_code==200
    assert response.json()["status"]=="ok"

def test_api_docs_available():
    response=TestClient(app).get("/openapi.json")
    assert response.status_code==200
